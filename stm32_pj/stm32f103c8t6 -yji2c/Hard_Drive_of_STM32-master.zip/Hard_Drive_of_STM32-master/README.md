# STM32基于Cube IDE的硬件驱动

## 介绍

```c
1.使用STM32的硬件IIC进行于0.96寸OLED的通信传输
2.使用STM32的硬件SPI进行W25Qxx型号的Flash读写
3.使用printf重定向进行串口打印，也可以重定向到其他任何的传输函数中去，甚至到显示外设之中均可
```

### 软件架构

使用STM32 Cube IDE
